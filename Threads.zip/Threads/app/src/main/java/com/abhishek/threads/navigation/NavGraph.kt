package com.abhishek.threads.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.abhishek.threads.screens.AddThreads
import com.abhishek.threads.screens.BottomNav
import com.abhishek.threads.screens.Home
import com.abhishek.threads.screens.Login
import com.abhishek.threads.screens.Notification
import com.abhishek.threads.screens.OtherUsers
import com.abhishek.threads.screens.Profile
import com.abhishek.threads.screens.Register
import com.abhishek.threads.screens.Search
import com.abhishek.threads.screens.Splash


@Composable
fun NavGraph(navController: NavHostController) {
    NavHost(navController = navController,
        startDestination = Routes.Splash.routes) {

        composable(Routes.Splash.routes) {
            Splash(navController)
        }
        composable(Routes.Home.routes) {
            Home(navController)
        }
        composable(Routes.Notification.routes) {
            Notification()
        }
        composable(Routes.Search.routes) {
            Search(navController)
        }
        composable(Routes.AddThread.routes) {
            AddThreads(navController)
        }
        composable(Routes.Profile.routes) {
            Profile(navController)
        }
        composable(Routes.BottomNav.routes) {
            BottomNav(navController)
        }
        composable(Routes.Login.routes) {
            Login(navController)
        }
        composable(Routes.Register.routes) {
            Register(navController)
        }
        composable(Routes.OtherUsers.routes) {
            val data = it.arguments!!.getString("data")
            OtherUsers(navController,data!!)
        }


    }
}