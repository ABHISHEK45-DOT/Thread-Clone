package com.abhishek.threads.model

data class ThreadModel(
    val thread: String= "",
    val image: String = "",
    val userId: String = "",
    val timeStamp: String = ""
)