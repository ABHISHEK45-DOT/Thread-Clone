package com.abhishek.threads.screens

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.navigation.NavGraph


@Composable
fun Notification(){
    
    Text(text = "Notification")

}